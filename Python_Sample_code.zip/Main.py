import random 
from random import choice
import re
"""
Creator: Christian Banks
Date Initiated: 09/20/2019
Date Completed: 09/28/2019
Purpose: Generates names in a range of 400 and also generates occupations and badge numbers based on that amount,
there are only a set number of occupations and every name and badge number is created from some limited pool of items which
are random. The program starts by informing the user of their options and executes various functions to accomodate them.

Notes: You will see some code about a Queue and a Elevator class, origianlly the purpose of this application was to run a elevator
simulator which would allow these people to enter a elevator throughout a days time and then record their information and ask the user
if they wanted to see what each individual had done throughout the day i.e what floors they went to and which elevator they took as well
as what time they took them, when they went on lunch or when they left the building.
For special people like the Ceo and VP they would have different times they would arrive as well as duties 
and work hours. As of this writing none of this is completed. Completion is maybe 60% a best
"""

"""
#Queue or Line of Person Class
class Queue(object):
	Max = 8
	PassengersList = []				#Just a list of passengers in the Queue
	def __init__(self):
		self.current = -1
	def isEmpty(self):
		if (self.current >= 0):
			print "List is not empty. Has '%s' item(s) " %(self.current+1)
			return False
		else:
			print "There are no passengers in this elevator." 
			return True
	def isFull(self):
		if (self.current == self.Max):
			print "List is full!!"
			return True
		else:
			print "List not full. Has '%s' item(s) " %(self.current+2)
			return False
	def Dequeue(self):
		if (self.current >= 0):
			ItemToRemove = self.PassengersList[1]
			self.current -= 1
			self.PassengersList.remove(ItemToRemove)
	def Enqueue(self, person):
		if (self.current < self.Max):
			self.current += 1
			self.PassengersList.append(person)
	def PrintQueue(self):
		print "Passenger count: %s" %(self.current+1)
		if self.isEmpty() == False:
			print "///////////////////////Passengers in the elevator///////////////////////"
			for item in range(self.current+1):
				self.PassengersList[item].PrintFullName()
			print "///////////////////////End of the list//////////////////////////////////"
"""
	
class Person(object):
	Occupation = ""
	#Every person will always start on the first floor
	current_floor = 1 
	def __init__(self, PFullName, PFirstName, PLastName, Badge):
		self._FullName = PFullName
		self._FirstName = PFirstName
		self._LastName = PLastName
		self.badge = Badge			#Badge or ID number
		
	#Simply print and return the badge number here
	def getBadge(self):
		return self.badge
	#Returns a string of the employees first Name
	def getFirstName(self):
		return str(self._FirstName)
	#Returns a string of teh employees last name	
	def getLastName(self):
		return str(self._LastName)
	#Returns a string of the employees full name	
	def getFullName(self):
		return str(self._FullName)
	#Prints the FirstName to the console
	def PrintFirstName(self):
		print str(self._FirstName)
	#Prints the LastName to the console
	def PrintLastName(self):
		print str(self._LastName)
	#Prints the FullName to the console
	def PrintFullName(self):
		print str(self._FullName)
	def PrintBadge(self):
		print str(self.badge)
	def SetOccupation(self, Oc):
		self.Occupation = Oc
		return
	def GetOccupation(self):
		return str(self.Occupation)
	def PrintAllInfo(self):
		if self.Occupation != "Ceo" and self.Occupation != "Vice President":
			print "%s is a %s with a badge ID: %s" %(self._FullName, self.Occupation, self.badge)
		else:
			print "%s is the %s with a badge ID: %s" %(self._FullName, self.Occupation, self.badge)
		
class Elevator(object):
	#ElevatorQueue = Queue()
	#Initially empty list of people to enter the elevator
	Passengers = []
	def __init__(self, elevatorID):
		self.elevatorID = elevatorID	#Current Elevator
		self.currentFloor = 1
		#self.ElevatorQueue = Queue()
	def AddPerson(self, person):
		pass
		"""
		if self.ElevatorQueue.isFull() == False:
			self.ElevatorQueue.Enqueue(person)
		#ElevatorQueue.append(person)
	def RemovePerson(self):
		self.ElevatorQueue.Dequeue()
	def PrintCurrentCapacity(self):
		print "Printing capacity for elevator %s." %(self.elevatorID)
		if (self.ElevatorQueue.isEmpty() == False):
			print "Current capacity for elevator %s: '%s'." %(self.elevatorID, self.ElevatorQueue.current+1)
	def PrintPassengers(self):
		self.ElevatorQueue.PrintQueue()"""
	def CallElevator(self, ToFloor):
		if (ToFloor >= 1 and ToFloor <= 5):
			if ToFloor == self.currentFloor:
				print "Elevator %s is already on floor '%s'."%(self.elevatorID, ToFloor)
			else:
				while (self.currentFloor != ToFloor):
					if (self.currentFloor < ToFloor):
						self.currentFloor += 1
						print "Elevator moving up!!"
					elif (self.currentFloor > ToFloor):
						print "Elevator moving down!!!"
						self.currentFloor -= 1
		else:
			print "Floor '%s' is out of range." %(ToFloor)

#For numbers only or can be used on the alphabet characters if lower or 
#uppercase is irrelevant. Should pass in the object only not its length
def getRandomInteger(source):
	random_int = random.randint(0, len(source) - 1)
	return random_int

#Get a uppercase letter from the alphabet value
def getUpperCaseLetter(alpha):
	#Start from the capitals of the alpha value which is 26 onward
	UpperChar = random.randint(26, len(alpha) - 1)
	return UpperChar

#Get a lowercase letter from the alphabet
def getLowerCaseLetter(alpha):
	#Start from the begginng up till z
	LowerChar = random.randint(0, (len(alpha)/2 - 1))
	return LowerChar

#Determines if a character should be upper or lowercase based on 
#a chance variable and returns that value as a string.
#Note: should only be used with the alphabet string passed in
def DetermineChar(alpha):
	chance = getRandomInteger(range(0, 2) )
	if (chance == 0):
		#print "Lowercase utilized"
		return str( alpha[getLowerCaseLetter(alpha)] )
	else:
		#print "Uppercase utilized"
		return str(alpha[getUpperCaseLetter(alpha)] )
	
def GenerateBadgeNums(Nums, alpha):
	# Generate random numbers 1 through 5 for conditions
	Rand = random.randint(1, 5)
	Key = ""
	KeyLength = 5				 #Length of the generated key
	
	# If the number is 1 follow special rules for this type which is
	# the first two characters are letters followed by 3 numbers
	if (Rand == 1):
		#print "Case 1"
		for i in range(KeyLength):
			if (i < 2):
				Key += alpha[getRandomInteger(alpha)]
			else:
				Key += str(getRandomInteger(Nums) )
	#basically do the opposite of the first case, last 3 are characters
	elif (Rand == 2):
		#print "Case 2"
		for i in range(KeyLength):
			if (i < 2):
				Key += str(getRandomInteger(Nums) )
			else:
				Key += alpha[getRandomInteger(alpha)]
	#Make the first, middle and last indices numbers and the others letters
	elif (Rand == 3):
		#print "Case 3"
		for i in range(KeyLength):
			if (i == 0 or i == (KeyLength/2) or i == (KeyLength - 1)):
				Key += str(getRandomInteger(Nums) )
			else:
				Key += alpha[getRandomInteger(alpha)]
	#Make the first and last item a number and the rest
	#a chance of being upper or lowercase letters
	elif (Rand == 4):
		#print "Case 4"
		for i in range(KeyLength):
			if (i == 0 or i == KeyLength - 1):
				Key += str(getRandomInteger(Nums) )
			elif (i > 0 and (i < KeyLength - 1) ):
				Key += DetermineChar(alpha)
	#Do the opposite of case 4 and make the first and last 
	# characters(upper or lower) and the rest numbers or characters
	elif (Rand == 5):
		#print "Case 5"
		for i in range(KeyLength):
			if (i == 0 or i == KeyLength - 1):
				Key += DetermineChar(alpha)
			else:
				NumorChar = getRandomInteger(range(0, 2) )
				#if 0 then make the next value a Number
				if (NumorChar == 0):
					Key += str(getRandomInteger(Nums) )
				#Otherwise it's a character that's upper or lower
				else:
					Key += DetermineChar(alpha)
	else:
		print "Something went wrong. Num is: %s" %(Rand)
		return ""
		
	#print "Generated key is : %s" %(Key)
	return Key
	
#Print the first and last names generated by the program
def PrintAllNames():
	for index, name in enumerate(FullNames):
		print str(index+1) + ": " + name

#Just prints all the badges numbers out the console
def PrintAllBadges():
	#Just Print all the Employee badges numers to the console in sets of 10 per line
	start = 0
	current = 10
	end = len(Employee_Badges) + 10
	while current != end:
		print str(start+1) + "-" + str(start + 10) + ": " , " ".join(Employee_Badges[start:current])
		start = current
		current += 10 
	
	print ""		#Just to end the line after the keys are printed out
		
#Print all First Names generated by the program
def PrintFirstNames():
	print "All first names"
	for index, FirstName in enumerate(FirstNames):
		print str(index+1) + ": " + FirstName

#Print all Last Names generated by the program
def PrintLastNames():
	print "All last names"
	for index, LastName in enumerate(LastNames):
		print str(index+1) + ": " + LastName
		
def PrintNameByIndex():
	LookForName = ''
	QuitorContinue = ''
	#Looks for a name based on a input value presented by the user with exception handling
	print "Attempting to print a name by index invoked!!"
	while QuitorContinue != 'q' and QuitorContinue != 'Q':
		try:
			#First ask the user if they want to continue or not by pressing q or c
			QuitorContinue = str(raw_input("Would you like to quit or continue? 'q' to quit, 'c' to continue: ") )
			
			#If c is pressed continue the loop and now ask the user for a index value
			if (QuitorContinue == 'c' or QuitorContinue == 'C'):
				LookForName = int(raw_input("Please enter a index value: "))
				
				#If the value input by LookForName isn't between 0 and the max
				#num of people raise a value error
				if (LookForName < 0 or LookForName >= PeopleCount):
					raise ValueError
					
				#If anything other than c or q is presse in the first prompt
				#Raise a exception and print out the users value as well as 
				#a response prompt
			else:
				#Don't raise an exception if the q key is pressed
				if (QuitorContinue != 'q' and QuitorContinue != 'Q'):
					raise Exception(QuitorContinue)
			#If a proper index value is printed end this loop
			break
			
		#Exception for any value that does not fit in the specified index
		#range
		except ValueError:
			print "Invalid!! Please print a index between 0 and %s\n" %(PeopleCount-1)
			
		#Exception for any choice value that is not c or q
		except Exception as inst:
			print "'%s' is not a valid answer" %(inst)
	
	#If the quit or continue value doesn't equal quit then 
	#search for the users specified name by index
	if (QuitorContinue != 'q' and QuitorContinue != 'Q'):
		PrintNameByIndexHelper(LookForName)
	#if the user did quit the search then print out a abort messageazxz
	else:
		print "Search by index aborted!!"
		return
		
#Print a specific name based on its index
def PrintNameByIndexHelper(index):
	
	if index >= 0 and index <= PeopleCount - 1:
		print "Valid index!!"
		if (index == 0):
			print str(index+1) + ": " + FullNames[index]
		else:
			print str(index) + ": " + FullNames[index]
		TryAgain = ""
		while TryAgain != 'N' and TryAgain != 'n':
			TryAgain = str(raw_input("Would you like to try again? 'Y' or 'N' : ") )
			if (TryAgain == 'Y' or TryAgain == 'y'):
				TryAgain = 'N'			#Set the rety option to N since we are going to call the main
										#function again anyway
				PrintNameByIndex()
			elif (TryAgain == 'N' or TryAgain == 'n'):
				print "Retry attempt aborted"
			else:
				print "'%s' is not a valid choice. Please retry" %(TryAgain)
		
	else:
		print "That index is out of range!!"
		
#The search functions that asks the user if they want to search a name and
#if so call the helper function to o the work
def SearchForName():
	SearchAName = ""
	while (SearchAName != 'N' and SearchAName != 'n'):
		SearchAName = str(raw_input("Would you like to search for a name? Y or N: ") )
		if (SearchAName == 'y' or SearchAName == 'Y'):
			SearchHelper()
		elif (SearchAName == 'n' or SearchAName == 'N'):
			print "Search aborted"
		else:
			print "%s is not a valid choice" %(SearchAName)
			
#Helper function that just searches for the name
def SearchHelper():
	Indicies = []		#To hold the index where matches are found
	#Ask the user for a name they want to find and store it into a variable
	#called search
	Search = str(raw_input(r"Please enter a name to search for: ") )
	#Loop through the total number of people and search for it using the 
	#EmployeeDict with the badges as the key by using the index value
	for index in range( (PeopleCount) ):
		equals = re.search(Search, str(EmployeeDict[Employee_Badges[index]].getFullName() ) )
		#if there is a match at an index add that index into the Indicies list
		if (equals):
			#print "Match found at: %s" %(index+1)
			Indicies.append(index)
	
	#If there are numbers stored in the Indicies variable then 
	#loop through them an print out the name, its position and the person's badge number
	if len(Indicies) > 0:
		for index in range(len(Indicies) ):
			print EmployeeDict[Employee_Badges[Indicies[index] ]].getFullName() , "at index: %s " %(Indicies[index] + 1) + \
			 "with a badge number: %s" %(employees[Indicies[index]].getBadge() )
	else:
		print "'%s' is not in the list" %(Search)

#This helper function simply prints out all the first and last names to the console
def PrintSampleNames():
	# This block of code just prints the first names out for the user to select
	print "\t\t\t\t\t\tFirst Names\n"
	start = 0
	currentIndex = 10
	#End = len(SampleFirstNames) - 1
	for _names in range(4):
		print "      ".join(SampleFirstNames[start:currentIndex])
		start = currentIndex
		currentIndex += 10
	
	# This block of code just prints the last names out for the user to select
	print "\n\t\t\t\t\t\tLast Names\n"
	start = 0
	currentIndex = 10
	#End = len(SampleFirstNames) - 1
	for _names in range(4):
		print "     ".join(SampleLastNames[start:currentIndex])
		start = currentIndex
		currentIndex += 10
	print ""

#Generate a random occupation from the global occupations list by first generating a random
#value and then using that value in the Occupations variable
def GenerateOccupation():
	randint = getRandomInteger(Occupations)
	return Occupations[randint]

def FindOccupation():
	#Simply out the users options to the console so they know what to type
	OCChoices = "\n\t\tOccupation list \n1:Ceo,  2:Vice President,  3:Software Developer\n4:Consultant,  5:Analyst, \
6:Manager\n7:Customer Specialist,  8:Security Specialist,  9:Database Specialist\n10:Network Specialist, \
11:Cloud Computer,  12:IT Leader,  13:HR, 14: Reprint Menu 0:exit\n"
	#Start by print those options to the screen initially
	print OCChoices
	FindJob = ""
	#Create a dictionary which maps the numbers 1 through 14 to the string created before
	OcDict = {1: "Ceo", 2: "Vice President", 3: "Software Developer", 4: "Consultant", 5: "Analyst", 6: "Manager",
	7: "Customer Specialist", 8: "Security Specialist", 9: "Database Specialist", 10: "Network Specialist", 
	11: "Cloud Computer", 12: "IT Leader", 13: "HR", 14: OCChoices}
	#While the user does not wish to exit this prompt
	while FindJob != 0:
		#Try to ask the user for a input string. If anything other than the numbers asked for are provided
		#run the exception unless the value is 0
		try:
			FindJob = int(raw_input("Please enter a number for the person with the occupation you'd like to find. \
14 to reprint list or 0 to quit: ") )
			if FindJob >= 1 and FindJob <= 14:
				if (FindJob != 14):
					print "Searching for %s!\n" % (OcDict[FindJob])
					for num in range(PeopleCount):
						if (employees[num].GetOccupation() == OcDict[FindJob]):
							employees[num].PrintAllInfo()
				#This is for formatting only 
				else:
					print OcDict[FindJob]
			#If the number is anything other than 1 through 14 run a valueerror execption, string as well
			else:
				raise ValueError
		except ValueError:
			#Just to changed the output if the value entered is 0 or not. If it is 0 this while condition will terminate
			if (FindJob != 0):
				print "Please input a value between 1 and 13."
			elif (FindJob == 0):
				print "Occupation search aborted!!!"

#What the user sees when then enter the program. Simply describes their options and handles everything that occurs in the main program
def MenuPrompt():
	print "Welcome!! This program prints sample data and names and allows you to search for them and their occupations\n"
	PrintSampleNames()	#Output all the first and last names to the console
	UserChoice = " " 
	#This block of code ask the user for their input and then acts accordingly, should execute at the end
	while (UserChoice != 8):
		try: 
			UserChoice = int(raw_input("Press 1 to search for a name, 2 to input a index(must be 0 - 399), 3 to find employees by job, \
			\n4 to print all names, 5 to print all badges, 6 to print all employee info, 7 to reprint sample names, 8 to abort. ") )
			
			if (UserChoice == 1):
				SearchForName()
			elif (UserChoice == 2):
				PrintNameByIndex()
			elif (UserChoice == 3):
				FindOccupation()
			elif (UserChoice == 4):
				PrintAllNames()
			elif (UserChoice == 5):
				PrintAllBadges()
			elif (UserChoice == 6):
				for num in range(PeopleCount):
					employees[num].PrintAllInfo()
				print ""
			elif (UserChoice == 7):
				PrintSampleNames()
			else:
				if (UserChoice != 8):
					raise ValueError
		except ValueError:
			print "\nPlease print a value between 1 and 7\n"
			
#elv = [Elevator(x) for x in range(1, 7)]
alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
#Can be change if you want keys with only certain numbers in them like i.e 1-4
NumRange = range(10) #0-9 
#Key = GenerateBadgeNums(NumRange, alphabet)
#Generate a specified list of random keys
Employee_Badges = [GenerateBadgeNums(NumRange, alphabet) for x in range(400)]

# Generate 40 sample first names
SampleFirstNames = ('Christian', 'Robert', 'Dante', 'Johnathan', 'Albert',
'Fred', 'Tom', 'Lilly', 'Norbit', 'Jessica', 'Rossie', 'Alexa', 'Alexis',
'Sean', 'Rebecca', 'Jack', 'Kimberly', 'Rosseta', 'Amy', 'Donta', 
'Jessie', 'Savannah', 'Camie', 'Kairi', 'Raven', 'Kiara','Justin', 
'Jevon', 'Stan', 'Issac', 'Lee', 'Dave', 'Keisha', 'Christina', 
'Jackie','Ned', 'Fredrick', 'Rachell', 'Charlie', 'Arthur')

# Generate 40 sample last names
SampleLastNames = ('Banks', 'Wilson', 'Logan', 'Archer', 'King', 'Elliot',
'Stone', 'Davis', 'Brown', 'Johnson', 'Miller', 'James', 'Marshall', 
'Randson', 'Perry', 'Scott', 'Coleman', 'Anderson', 'Morgan', 'Murphy',
'Walker', 'Sanders', 'Phillips', 'Robinson', 'Richter', 'Hernandez', 
'Edwards', 'Luke', 'Mills', 'Clark', 'Evans', 'Moore', 'Morrison', 'Rockford',
'Stonewall', 'Randie', 'Jordan', 'Simon', 'Townley', 'DeSanta')

# Number of People in the building 
PeopleCount = 400

#List of all the occupations
CEO = "Ceo"
HR = ["HR"] * 5
VP = "Vice President"
SoftwareDevelopers = ["Software Developer"] * 100
Consultants = ["Consultant"] * 40
Analysts = ["Analyst"] * 40
Managers = ["Manager"] * 24
CustomerSpecialists = ["Customer Specialist"]*39
SecuritySpecialists = ["Security Specialist"]*40
DatabaseSpecialists = ["Database Specialist"]*30
NetworkSpecialists = ["Network Specialist"]*30
CloudComputing = ["Cloud Computer"]*30
ITLeaderShip = ["IT Leader"]*20

#Create a list containig all available occupations at the company
Occupations = HR + SoftwareDevelopers + Consultants + Analysts + Managers \
+ CustomerSpecialists + SecuritySpecialists + DatabaseSpecialists + NetworkSpecialists \
+ CloudComputing + ITLeaderShip

#Add the CEO and VP since they are individual items
Occupations.append(CEO)
Occupations.append(VP)


Names = lambda FN, SPACE, LN: FN + SPACE + LN
FirstNames = [choice(SampleFirstNames) for i in range(PeopleCount)]
LastNames = [choice(SampleLastNames) for i in range(PeopleCount)]

FullNames = [Names(FirstNames[i], " ", LastNames[i]) for i in range(PeopleCount) ]

#Dictionary that tethers the Employees name and badge numbers togther
EmployeeDict = {}

employees = []
#Go through a range of max numbers and create temporary variable called newPerson which holds a 
#employees data. Then generate job for that employee and add it to that person. Remove the job
#from the occupations list and finally add that person data to the employees list
for Employee in range(PeopleCount):
	newPerson = Person(FullNames[Employee], FirstNames[Employee], LastNames[Employee], Employee_Badges[Employee])
	job = GenerateOccupation()
	newPerson.SetOccupation(job)
	Occupations.remove(job)
	employees.append(newPerson)

#If there is any data left in newPerson delete it since it was only temporary anyway 
if (newPerson):
	del newPerson

for num in range(PeopleCount):
	EmployeeDict.update( {Employee_Badges[num] : employees[num]} )

#EmployeeDict[Employee_Badges[0]].PrintBadge()
#print EmployeeDict[Employee_Badges[0]].getFullName()

num = 0

"""
#elv[0].CallElevator(4)
for value in range(8):
	elv[0].AddPerson(employees[value])
#elv[0].RemovePerson()
elv[0].PrintPassengers()
#elv[1].AddPerson(employees[11])
elv[0].PrintCurrentCapacity()
elv[1].PrintPassengers()"""

#For testing purposes only
"""
for num in range(PeopleCount):
	EmployeeDict[Employee_Badges[num] ].PrintAllInfo()"""
	
MenuPrompt()

print "\nAborting program!!"


	
